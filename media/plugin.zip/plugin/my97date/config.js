var langList = 
[
	{name:'en',	charset:'UTF-8'},
	{name:'zh-cn',	charset:'GBK'},
	{name:'zh-tw',	charset:'UTF-8'}
];

var skinList = 
[
	{name:'default',	charset:'GBK'},
	{name:'ext',	charset:'GBK'},
	{name:'blue',	charset:'GBK'}
];