/**
 * select样式插件
 * 前提条件：请引入jquery插件
 * @author Xiaojie.Xu
 */
(function ($) {
    var defaults = {
    };
    var constants = {
        CLASS_NAME : "x-select",
        EXPAND_CLASS : "expand"
    };
    $.fn.extend({
        xselect : function(options) {
            if($(this).length < 1) return ;
            options = $.extend({}, defaults, options);
            $(this).each(function() {
                $('<div></div>')
                    .addClass(constants.CLASS_NAME)
                    .addClass($(this).attr('class'))
                    .append('<a href="javascript:;"></a>')
                    .append('<ul></ul>')
                    .width($(this).outerWidth())
                    .find(">a")
                    .css("line-height", ($(this).outerHeight() - 2) + "px") // 2是上下边框
                    .css("min-height", ($(this).outerHeight() - 2) + "px") // 2是上下边框
                    .click(function(e) { // 主链接点击
                        // 阻止事件传递
                        e.stopPropagation();
                        // 展开/关闭
                        if($(this).parent().hasClass(constants.EXPAND_CLASS)) {
                            $(this).parent().removeClass(constants.EXPAND_CLASS);
                        } else {
                            $("div." + constants.CLASS_NAME + "." + constants.EXPAND_CLASS)
                                .not($(this))
                                .removeClass(constants.EXPAND_CLASS);
                            $(this).parent().addClass(constants.EXPAND_CLASS);
                            var width = $(this).outerWidth();
                            $(this).siblings('ul').find('li>a').each(function() {
                                if($(this).outerWidth() > width) width = $(this).outerWidth();
                            });
                            $(this).siblings('ul').width(width);
                        }
                    })
                    .next("ul")
                    .css("top", ($(this).outerHeight() - 1) + "px")
                    .end().end()
                    .insertAfter($(this));
                _init_lis($(this));
                _bind_reset($(this));
            }).addClass(constants.CLASS_NAME);
            // 点击其他区域隐藏
            $(document).click(function(e) {
                var $sdiv = $("div." + constants.CLASS_NAME + "." + constants.EXPAND_CLASS);
                if(e.target != $sdiv[0]){
                    $sdiv.removeClass(constants.EXPAND_CLASS);
                }
            });
        }
    });
    // 根据select初始化ul选项lis
    var _init_lis = function($select) {
        var $box = $select.next("div." + constants.CLASS_NAME),
            $ul = $box.find(">ul").empty(),
            $main = $box.find(">a"),
            $options = $select.find('option'),
            $default = $options.filter(':selected') || $options.filter(':first');
        if($default.length > 0) { // 设置默认值
            $main.text($default.text());
            $box.data("default", $select.val());
        }
        $options.each(function() {
            $('<a href="javascript:;"></a>')
                .text($(this).text())
                .attr("data-value", $(this).attr("value"))
                .css("line-height", ($select.outerHeight() - 2) + "px") // 2是上下边框
                .wrap('<li></li>')
                .parent()
                .addClass($(this).attr("selected") ? "selected" : "")
                .click(function() {
                    _onSelect($(this).children('a'));
                })
                .appendTo($ul);
        });
    };
    var _onSelect = function($link, noNeedTrigger) {
        var $box = $link.closest("div." + constants.CLASS_NAME).removeClass(constants.EXPAND_CLASS),
            $select = $box.prev("select." + constants.CLASS_NAME);
        if($select.val() == $link.attr("data-value")) return;
        // 改“选中”样式
        $link.parent().parent().siblings("a")
            .text($link.text())
            .end().end()
            .siblings("li")
            .removeClass("selected")
            .end()
            .addClass("selected");
        // 设置新选中的值
        $select.val($link.attr("data-value"));
        // 联动请求
        _request($select);
        // 触发事件
        if(!noNeedTrigger) $select.trigger("change").trigger("click");
    };
    // 联动请求
    var _request = function($select){
        var $target = $('select.' + constants.CLASS_NAME + '[data-rel="' + $select.attr("name") + '"]');
        if($target.length < 1) return ;
        $.ajax({
            url : $target.attr("data-url") + "=" + $select.val(),
            type : "get",
            dataType : "json",
            success : function(data) {
                $target.empty();
                $.each(data, function(i, obj) {
                    $target.append('<option value="' + obj.value + '"' + (i == 0 ? ' selected="selected"' : '') + '>' + obj.text + '</option>');
                });
                _init_lis($target);
                _request($target);
            }
        });
    };
    // 响应reset事件
    var _bind_reset = function($select) {
        var $form = $select.closest('form'),
            $box = $select.next("div." + constants.CLASS_NAME),
            $link = $box.find('a[data-value="' + $box.data("default") + '"]');
        $form && $form.on('reset', function(){
            _onSelect($link, true);
        });
    };
var doc = document,
    jsfiles = doc.scripts,
    jsPath = jsfiles[jsfiles.length - 1].src,
    dir = jsPath.substring(0, jsPath.lastIndexOf("/") + 1);
doc.write('<link type="text/css" rel="stylesheet" href="' + dir + 'css/xselect.css">');
})(jQuery);