/**
 * 分页插件
 */
(function($) {
window.xpager = function(options) {
	options = $.extend({
		container : null, // 容器
		max : 9, // 最多显示的页码个数
		first : '‹‹',
		last : '››',
		prev : '‹',
		next : '›',
		showBtn : true, 	// 是否一直显示四个功能按钮
		showText : true,	// 是否显示省略号...
		curr : 1,			// 当前页
		sizeArray : [10,15,20,50,100],		// 每页最大数可选值
		size : 0,			// 每页最大数
		count : 0,			// 总条数
		onJump : function(curr){}, // 页码点击回调
		onSelect : function(size){} // 选择每页最大条数回调
	}, options);
	var $container = $('<div></div>').addClass("x-pager").appendTo(options.container);
	// 计算总页数
	function getTotalPage(pageSize, totalCount) {
		var totalPage = parseInt(totalCount / pageSize); // 总页数
		totalPage = totalCount % pageSize > 0 ? totalPage + 1 : totalPage;
		return totalPage;
	}
	var totalPage = getTotalPage(options.size, options.count);
	// 计算要显示的起始页面
	var startNo = 1; 
    var endNo = totalPage;
    if(totalPage > options.max) {
    	var temp = Math.floor(options.max / 2);
        if(options.curr <= temp + 1) {
            startNo = 1;
            endNo = options.max;
        } else if(options.curr < totalPage - temp) {
            startNo = options.curr - temp;
            endNo = options.curr + temp;
        } else {
            startNo = totalPage - options.max + 1;
            endNo = totalPage;
        }
    }
    // 创建页码
    var $pageList = $('<div></div>').addClass("x-page-list");
    for(var i = startNo; i <= endNo; i ++) {
    	$pageList.append('<a ' + (i == options.curr ? 'class="selected"' : '') + ' href="javascript:;">' + i + '</a>');
    }
    if(options.showText && startNo > 1) {
    	$pageList.prepend('<span>...</span>');
    }
    if(options.showText && endNo < totalPage) {
    	$pageList.append('<span>...</span>');
    }
    if(options.showBtn || options.curr > 1) {
    	var disable = options.curr == 1 ? 'disable' : '';
    	$pageList.prepend('<a class="prev ' + disable + '" href="javascript:;">' + options.prev + '</a>');
    	$pageList.prepend('<a class="first ' + disable + '" href="javascript:;">' + options.first + '</a>');
    }
    if(options.showBtn || options.curr < totalPage) {
    	var disable = options.curr == totalPage ? 'disable' : '';
    	$pageList.append('<a class="next ' + disable + '" href="javascript:;">' + options.next + '</a>');
    	$pageList.append('<a class="last ' + disable + '" href="javascript:;">' + options.last + '</a>');
    }
    $pageList.appendTo($container);
    // 绑定事件
    $pageList.find(">a").click(function() {
    	if($(this).hasClass("selected") || $(this).hasClass("disable")) return false;
    	var curr = parseInt($(this).text());
    	if($(this).hasClass("first")) {
    		curr = 1;
    	} else if($(this).hasClass("last")) {
    		curr = totalPage;
    	} else if($(this).hasClass("prev")) {
    		curr = options.curr - 1;
    	} else if($(this).hasClass("next")) {
    		curr = options.curr + 1;
    	}
    	options.onJump(curr);
    });
    // 每页最大条数下拉框
    var isIn = function(array, a) {
        for(var i in array) {
        	if(parseInt(array[i]) == parseInt(a)) return true;
        }
        return false;
    };
	if(!isIn(options.sizeArray, options.size)) {
		options.sizeArray = options.sizeArray.concat(options.size);
	}
	options.sizeArray = options.sizeArray.sort(function(a, b) {
		return a - b;
	});
	var $perPage = $('<div></div>').addClass("x-per-page");
	var $select = $('<select></select>').change(function() {
    	options.onSelect($(this).val());
	});
	$.each(options.sizeArray, function(k, v) {
		$select.append('<option ' + (v == options.size ? 'selected="selected"' : '') + '>' + v + '</option>');
	});
	$perPage.append('<span>每页显示</span>')
		.append($select)
		.append('<span>条，共' + options.count + '条</span>')
		.prependTo($container);
	// 直接跳页
	var $goPage = $('<div></div>').addClass("x-go-page");
	var $input = $('<input class="input" type="number" min="1"/>').keyup(function(e) {
		if(e.keyCode == 13) { // 回车
			$(this).siblings('input[type="button"]').click();
		} else {
			this.value = this.value.replace(/\D/, '');
		}
	});
	var $button = $('<input type=\"button\" value=\"Go\" />').click(function() {
		var v = $(this).siblings('input[type="number"]').val();
		if(v.trim() == "") return false;
		var curPage = parseInt(v);
		curPage = curPage < 1 ? 1 : curPage > totalPage ? totalPage : curPage;
		options.onJump(curPage);
	});
	$goPage.append('<span>共' + totalPage + '页， 跳至</span>')
		.append($input)
		.append($button)
		.appendTo($container);
};
var doc = document,
    jsfiles = doc.scripts,
    jsPath = jsfiles[jsfiles.length - 1].src,
    dir = jsPath.substring(0, jsPath.lastIndexOf("/") + 1);
doc.write('<link type="text/css" rel="stylesheet" href="' + dir + 'css/xpager.css">');
})(jQuery);

