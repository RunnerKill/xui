/**
 * xswitch样式插件
 * 前提条件：请引入jquery插件
 * @author Xiaojie.Xu
 */
(function ($) {
    var defaults = {
    	skin : "default",
    	on : "ON",
    	off : "OFF",
    	speed : "fast",
    	value : "0/1"
    };
    var constants = {
    	CLASS_NAME : "x-switch"
    };
    $.fn.extend({
    	xswitch : function(options) {
    		if($(this).length < 1) return ;
    		options = $.extend({}, defaults, options);
    		$(this).each(function() {
    			var _self = this,
    			    value = ($(_self).attr("value") || options.value).split("/"),
    			    text = ($(_self).attr("data-text") || "").split("/");
    			$(this)
    				.addClass(constants.CLASS_NAME)
    				.attr("disabled", "disabled");
                var $input = $('<input type="hidden" />')
                    .attr("name", $(_self).attr("name"))
                    .val(value[0])
                    .change(function() {
                        eval($(_self).attr("onchange"));
                    })
                    .click(function() {
                        eval($(_self).attr("onclick"));
                    })
                    .insertAfter($(_self));
    			var $switch = $("<div></div>")
    				.text(text[1] || options.on)
    				.addClass(constants.CLASS_NAME)
    				.addClass($(_self).attr("data-theme") || options.skin)
    				.append('<b><i></i>' + (text[0] || options.off) + '</b>')
    				.insertAfter($(_self))
    				.click(function() {
    					if(!$(this).hasClass("checked")) {
    					    _on({
    		                    check : $input,
    		                    swt : $(this),
    		                    speed : options.speed,
    		                    value : value[1]
    					    });
    					} else {
    					    _off({
                                check : $input,
                                swt : $(this),
                                speed : options.speed,
                                value : value[0]
                            });
    					}
    				});
    			if(this.checked) $switch.click();
    			$switch.data("default", $switch.hasClass("checked"));
                _bind_reset({
                    check : $input,
                    swt : $switch,
                    speed : options.speed
                }, value);
    		});
    	}
    });
    var _on = function(opt, noNeedTrigger) {
        opt.swt.addClass("checked");
        _swipe($.extend(opt, {
            left : opt.swt.outerWidth() - opt.swt.find("i").outerWidth()
        }), noNeedTrigger);
    };
    var _off = function(opt, noNeedTrigger) {
        opt.swt.removeClass("checked");
        _swipe($.extend(opt, {
            left : -1
        }), noNeedTrigger);
    };
    var _swipe = function(opt, noNeedTrigger) {
        opt.check.val(opt.value);
        opt.swt.find("b").stop().animate({
            "left" : opt.left + "px"
        }, opt.speed, "linear", function() {
            if(!noNeedTrigger) opt.check.trigger("change");
        });
    };
    var _bind_reset = function(opt, value) {
        var $switch = opt.swt,
            $form = $switch.closest('form'),
            dchecked = $switch.data("default");
        $form && $form.on('reset', function(){
            if(dchecked) _on($.extend(opt, {value : value[1]}), true);
            else _off($.extend(opt, {value : value[0]}), true);
        });
    };
var doc = document,
    jsfiles = doc.scripts,
    jsPath = jsfiles[jsfiles.length - 1].src,
    dir = jsPath.substring(0, jsPath.lastIndexOf("/") + 1);
doc.write('<link type="text/css" rel="stylesheet" href="' + dir + 'css/xswitch.css">');
doc.write('<link type="text/css" rel="stylesheet" href="' + dir + 'css/xswitch.skin.css">');
})(jQuery);