/**
 * 手机预览插件
 */
(function($) {
window.xmobile = function(options) {    
    options = $.extend({
        model : true,		// 是否开启遮罩层
        bg : ["#000", 0.3],	// 遮罩层样式
        title : "未知标题",	// 标题
        url : null,			// iframe的url地址
        content : null		// html内容字符串
    }, options);
    var $previewer = $('<div class="mobile-iphone no-bg">' +
            '<div class="iphone">' +
            '<div class="screen">' +
                '<h4 class="title">' + options.title + '</h4>' +
                (options.url ?
                '<div class="iframe"><iframe src="' + options.url + '"></iframe></div>' :
                '<div class="content">' + options.content + '</div>') +
            '</div></div></div>');
    $('<div class="close"></div>').click(function() {
        $previewer.remove();
    }).appendTo($previewer);
    if(options.model) {
        $previewer.removeClass("no-bg");
        $('<div class="bg"></div>').css({
            "background-color" : options.bg[0],
            "opacity" : options.bg[1]
        }).prependTo($previewer);
    }
    $("body").append($previewer);
    this.source = $previewer;
};

xmobile.prototype = {
    getContent : function() {
        return this.source.find(".content").html();
    },
    setContent : function(html) {
        this.source.find(".content").html(html);
    },
    close : function() {
        this.source.remove();
    }
};
var doc = document,
    jsfiles = doc.scripts,
    jsPath = jsfiles[jsfiles.length - 1].src,
    dir = jsPath.substring(0, jsPath.lastIndexOf("/") + 1);
doc.write('<link type="text/css" rel="stylesheet" href="' + dir + 'xmobile.css">');
})(jQuery);
