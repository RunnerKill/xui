/**
 * UE external plugin
 * @author Xiaojie.Xu
 */
(function ($) {
    var defaults = {
        width : 800,
        height : 300,
        toolbars : [
             'undo', //撤销
             'redo', //重做
             'bold', //加粗
             'italic', //斜体
             'underline', //下划线
             'superscript', //上标
             'inserttable', //插入表格
             'link', //超链接
             'horizontal', //分隔线
             '|',
             'formatmatch', //格式刷
             'removeformat', //清除格式
             'forecolor', //字体颜色
             'backcolor', //背景色
             'paragraph', //段落格式
             'fontfamily', //字体
             'fontsize', //字号
             '|',
             'justifyleft', //居左对齐
             'justifyright', //居右对齐
             'justifycenter', //居中对齐
             'justifyjustify', //两端对齐
             'insertorderedlist', //有序列表
             'insertunorderedlist', //无序列表
             'rowspacingtop', //段前距
             'rowspacingbottom', //段后距
             'lineheight', //行间距
             'imagenone', //默认
             'imageleft', //左浮动
             'imageright', //右浮动
             'imagecenter', //居中
             '|',
             'spechars', // 符号
             'emotion', // 表情
             'background', // 背景
             'searchreplace', //查询替换
             'selectall', //全选
             'cleardoc', //清空文档
             'print', //打印
             'source' //源代码
        ],
        ready : function(editor) {}
    };
    var root = function(){var a=location.href;var b=location.pathname;var c=a.substring(0,a.indexOf(b));var d=b.substring(0,b.substr(1).indexOf('/')+1);return c+d+"/";}();
    var _UE_OPTIONS_NUM_ = 0;
    $.fn.extend({
        UEditor : function(options) {
            options = $.extend({}, defaults, options);
            $(this).each(function() {
                options.name = $(this).attr("name");
                if(!options.name) throw "no attribute('name')."
                options.srcobj = $(this);
                // 保存全局变量
                var index = _UE_OPTIONS_NUM_ ++;
                var opt = $.extend(true, {}, options);
                eval('window._UE_OPTIONS_' + index + ' = opt');
                // 加载层
                $('<div class="ue-loading">编辑器始化中...</div>').css({
                    "display" : "block",
                    "width" : (options.width - 2) + "px",
                    "height" : (options.height - 2) + "px",
                    "line-height" : (options.height - 2) + "px",
                    "border" : "1px solid #cccccc",
                    "border-radius" : "4px",
                    "background-color" : "#efefef",
                    "color" : "#000000",
                    "text-align" : "center"
                }).insertAfter($(this));
                // 隐藏文本域
                $(this).hide();
                // 创建iframe
                $('<iframe class="ue-container"></iframe>').css({
                    "display" : "none",
                    "border" : "none",
                    "width" : options.width,
                    "height" : options.height
                }).attr({
                    "src" : root + "media/plugin/ueditor/iframe.html#" + index
                }).load(function() {
                    try{
                        eval('delete window._UE_OPTIONS_' + index); // 清除全局变量
                    } catch(e) {
                        eval('window._UE_OPTIONS_' + index + ' = undefined');
                    }
                }).insertBefore($(this));
            });
        },
        setContent : function(html, append) {
            var $textarea = $(this),
                ue = $textarea.data("ueditor");
            if(!$textarea.is('textarea') || !ue) return ;
            ue.setContent(html, append ? false : true);
        },
        getContent : function() {
            var $textarea = $(this),
                ue = $textarea.data("ueditor");
            if(!$textarea.is('textarea') || !ue) return ;
            return ue.getContent();
        }
    });
})(jQuery);