/**
 * 微信编辑器
 * @author Xiaojie.Xu
 * @version v1.1.0
 * @date 2016/5/17
 */
$(function() {
    // Get options from parent window by 'index'
    var url = window.location.href,
        index = url.substring(url.lastIndexOf("#") + 1),
        options = eval('window.parent._UE_OPTIONS_' + index),
        defaultContent = options.srcobj.val();
	// UE customization request
    var root = function(){var a=location.href;var b=location.pathname;var c=a.substring(0,a.indexOf(b));var d=b.substring(0,b.substr(1).indexOf('/')+1);return c+d+"/";}();
	UE.Editor.prototype._bkGetActionUrl = UE.Editor.prototype.getActionUrl;
	UE.Editor.prototype.getActionUrl = function(action) {
		if(action == 'config') { // main config
	        return 'jsp/config.json';
	    } else if(action == 'uploadimage' || action == 'uploadscrawl' || action == 'uploadvideo' || action == 'uploadfile') { // upload
	        return root + 'ue/upload';
	    } else if(action == 'catchimage') { // online image
	    	return root + 'ue/catch';
	    } else if(action == 'listimage' || action == 'listfile') { // list files
	    	return root + 'ue/list';
	    } else {
	        return this._bkGetActionUrl.call(this, action);
	    }
	};
	// UE constructor
	var editor = UE.getEditor("editor", {
	    initialFrameWidth: options.width - 2,
	    initialFrameHeight: options.height,
		topOffset: 0,
		autoFloatEnabled: false,
		autoHeightEnabled: false,
		allowDivTransToP: false,
		enableAutoSave: false, //启用自动保存
		elementPathEnabled: false, //是否启用元素路径，默认是显示
		wordCount: false, //是否开启字数统计
		initialContent: defaultContent,
		initialStyle: "body {font:14px/22px Microsoft Yahei,Arial,sans-serif;}" +
				"blockquote,q {margin:0; padding:0;}" +
				"p {line-height:1em;}",
		autotypeset: {
			removeEmptyline: true
		},
		toolbars: [options.toolbars]
	});
	// UE main config
	editor.ready(function() {
	    // hide the loading area
	    options.srcobj.next('div.ue-loading').hide();
	    options.srcobj.prev('iframe.ue-container').show();
	    // bind the reset event
	    var $form = options.srcobj.closest('form');
        $form && $form.on('reset', function(){
            editor.setContent(defaultContent);
        });
	    // reset editor's height
	    var toolbar_height = $('#editor').find('.edui-editor-toolbarbox').height();
	    $('#editor').find('.edui-editor-iframeholder').height(options.height - toolbar_height - 2);
		editor.addListener('contentchange', function() {
		    options.srcobj.val(this.getContent()).trigger("change");
		});
		options.ready(editor);
	    // provide a interface
		options.srcobj.data('ueditor', editor);
	});
	// disable the "Backspace" key down
	document.onkeydown = function(e) {
		if (!e) e = window.event;
		if ((e.keyCode == 8) // BackSpace 8;
				&& ((e.srcElement.type != "text"
				&& e.srcElement.type != "textarea"
				&& e.srcElement.type != "password"
				&& $(e.srcElement).attr("contenteditable") != "true")
				|| e.srcElement.readOnly == true)) {
			e.keyCode = 0;
			e.returnValue = false;
		}
		return true;
	};
});
